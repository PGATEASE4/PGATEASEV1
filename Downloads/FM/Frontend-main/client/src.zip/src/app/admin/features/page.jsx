export default function FeaturesPage() {
  return <div>Admin Features Page</div>;
}
